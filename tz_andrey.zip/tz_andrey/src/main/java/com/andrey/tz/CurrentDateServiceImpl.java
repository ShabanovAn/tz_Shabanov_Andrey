package com.andrey.tz;

import java.time.LocalDateTime;

public class CurrentDateServiceImpl implements CurrentDateService {

    @Override
    public LocalDateTime getNow() {
        return LocalDateTime.now();
    }
}
