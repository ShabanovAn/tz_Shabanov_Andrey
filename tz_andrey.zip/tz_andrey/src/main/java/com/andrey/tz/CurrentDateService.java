package com.andrey.tz;

import java.time.LocalDateTime;

public interface CurrentDateService {

    LocalDateTime getNow();
}
